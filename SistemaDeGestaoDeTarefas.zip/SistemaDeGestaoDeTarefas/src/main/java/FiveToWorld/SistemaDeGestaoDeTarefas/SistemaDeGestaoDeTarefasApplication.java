package FiveToWorld.SistemaDeGestaoDeTarefas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaDeGestaoDeTarefasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaDeGestaoDeTarefasApplication.class, args);
	}

}
